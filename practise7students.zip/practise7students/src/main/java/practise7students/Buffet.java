package practise7students;
import java.util.concurrent.Semaphore;

public class Buffet {
    public static void main(String[] args) {
        final int NUM_STUDENTS = 7;
        final int NUM_SEATS = 1;
        final int NUM_TABLE = 2;
        System.out.println("Шалунова А.С., РИБО-01-21, Практика №7, Вариант №2");

        Semaphore seats = new Semaphore(NUM_SEATS);
        Semaphore table = new Semaphore(NUM_TABLE);

        Thread[] threads = new Thread[NUM_STUDENTS];

        for (int i = 0; i < NUM_STUDENTS; i++) {
            final int studentNum = i + 1;
            threads[i] = new Thread(() -> {
                try {
                    System.out.printf("Student%d waiting%n", studentNum);
                    seats.acquire();
                    table.acquire();
                    System.out.printf("Student%d eating%n", studentNum);
                    Thread.sleep(3000);
                    table.release();
                    System.out.printf("Student%d exit%n", studentNum);
                    seats.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            threads[i].start();
        }
    }
}